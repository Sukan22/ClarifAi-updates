import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

type Story = {
  usid: string;
  title: string;
  role: string;
  story: string;
  description: string;
  acceptanceCriteria: string[];
  tshirt_size: string;
  priority: string;
  tags: string[];
  confidence: number;
  priorityScore?: number;
};

interface EditStoryModalProps {
  story: Story | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedStory: Story) => void;
}

export default function EditStoryModal({ story, isOpen, onClose, onSave }: EditStoryModalProps) {
  const [editedStory, setEditedStory] = useState<Story | null>(story);

  const handleChange = (field: keyof Story, value: string | string[]) => {
    if (editedStory) {
      setEditedStory({ ...editedStory, [field]: value });
    }
  };

  const handleSave = () => {
    if (editedStory) {
      const normalizedConfidence =
        typeof editedStory.confidence === "string"
          ? editedStory.confidence.toLowerCase() === "high"
            ? 0.8
            : editedStory.confidence.toLowerCase() === "medium"
            ? 0.5
            : 0.2
          : editedStory.confidence ?? 0.5;

      const normalizedStory = { ...editedStory, confidence: normalizedConfidence };
      onSave(normalizedStory);
      onClose();
    }
  };

  if (!editedStory) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[800px] bg-[#1a1a1a] text-white p-4 rounded-xl shadow-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-sm text-gray-400">Edit User Story</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label className="text-sm text-gray-400 block mb-1">User Story ID</label>
            <input
              type="text"
              value={editedStory.usid}
              disabled
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-gray-400 cursor-not-allowed"
            />
          </div>
          <div>
            <label className="text-sm text-gray-400 block mb-1">Confidence Score</label>
            <input
              type="text"
              value={editedStory.confidence.toString()}
              disabled
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-gray-400 cursor-not-allowed"
            />
          </div>
          <div>
            <label className="text-sm text-gray-400 block mb-1">Title</label>
            <input
              type="text"
              value={editedStory.title}
              onChange={(e) => handleChange("title", e.target.value)}
              placeholder="Title"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-sm text-gray-400 block mb-1">User Story</label>
            <textarea
              value={editedStory.story}
              onChange={(e) => handleChange("story", e.target.value)}
              placeholder="User Story"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white h-24 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-sm text-gray-400 block mb-1">Description</label>
            <textarea
              value={editedStory.description}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="Description"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white h-24 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-sm text-gray-400 block mb-1">Acceptance Criteria</label>
            <textarea
              value={editedStory.acceptanceCriteria.join("\n")}
              onChange={(e) => handleChange("acceptanceCriteria", e.target.value.split("\n"))}
              placeholder="Acceptance Criteria (one per line)"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white h-32 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-sm text-gray-400 block mb-1">Labels/Tags</label>
            <textarea
              value={editedStory.tags.join("\n")}
              onChange={(e) => handleChange("tags", e.target.value.split("\n"))}
              placeholder="Tags (one per line)"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white h-32 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-sm text-gray-400 block mb-1">Priority</label>
            <input
              type="text"
              value={editedStory.priority}
              onChange={(e) => handleChange("priority", e.target.value)}
              placeholder="Priority"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-sm text-gray-400 block mb-1">T-Shirt Size</label>
            <input
              type="text"
              value={editedStory.tshirt_size}
              onChange={(e) => handleChange("tshirt_size", e.target.value)}
              placeholder="T-Shirt Size"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-sm text-gray-400 block mb-1">Role</label>
            <input
              type="text"
              value={editedStory.role}
              onChange={(e) => handleChange("role", e.target.value)}
              placeholder="Role"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <DialogFooter className="bg-[#1a1a1a] border-t border-gray-700 p-4">
          <Button variant="ghost" onClick={onClose} className="mr-auto">Cancel</Button>
          <Button onClick={handleSave}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}