'use client';

import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { BrushCleaning, ChevronDown, ChevronsUpDown, ChevronUp, CirclePlus, EllipsisVertical, FunnelX, RotateCcw } from 'lucide-react';
import { Download } from 'lucide-react';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandGroup,
  CommandItem,
} from "@/components/ui/command";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { ConfidenceBadge } from "./ConfidenceBadge";

type GherkinScenario = {
  name: string;
  steps: string[];
};

type TestCase = {
  test_id: string;
  title: string;
  precondition: string;
  steps: string[];
  expected_result: string;
  priority: string;
  tags: string[];
};

type TraceabilityEntry = {
  user_story_id: string;
  usid: string;
  user_story: string;
  acceptance_criteria: string[];
  gherkin_feature: string;
  gherkin_scenarios: GherkinScenario[];
  test_cases: TestCase[];
};

const handleDownload = (entries: TraceabilityEntry[]) => {
  const jsonData = entries.map(entry => ({
    "User Story ID": entry.user_story_id,
    "US ID": entry.usid,
    "User Story": entry.user_story,
    "Acceptance Criteria": entry.acceptance_criteria,
    "Gherkin Feature": entry.gherkin_feature,
    "Gherkin Scenarios": entry.gherkin_scenarios,
    "Test Cases": entry.test_cases.map(tc => ({
      test_id: tc.test_id,
      title: tc.title,
      precondition: tc.precondition,
      steps: tc.steps,
      expected_result: tc.expected_result,
      priority: tc.priority,
      tags: tc.tags
    }))
  }));

  const blob = new Blob([JSON.stringify(jsonData, null, 2)], {
    type: 'application/json'
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'Figma_Traceability_Matrix.json';
  link.click();
  URL.revokeObjectURL(url);
};

interface TraceabilityTabProps {
  goToLogs?: () => void;
  traceabilityData: TraceabilityEntry[];
  combinedPayload: {
    user_stories: any[];
    gherkin_scenarios: any[];
    test_cases: any[];
  };
}

export default function FigmaTraceabilityTab({ goToLogs, traceabilityData, combinedPayload }: TraceabilityTabProps) {
  const [entries, setEntries] = useState<TraceabilityEntry[]>(traceabilityData);
  const [requirementTypeFilter, setRequirementTypeFilter] = useState<string[]>([]);
  const [checkedMap, setCheckedMap] = useState<Record<string, boolean>>({});
  const selectedEntriesForDownload = entries.filter((entry) => checkedMap[entry.user_story_id]);
  const isDownloadEnabled = Object.values(checkedMap).some(Boolean);

  const toggleDownloadCheckbox = (id: string) => {
    setCheckedMap((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const [showSuccess, setShowSuccess] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSuccess(false);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  const toggleSelectAllDownloadCheckboxes = (checked: boolean) => {
    const newMap: Record<string, boolean> = {};
    entries.forEach((entry) => {
      newMap[entry.user_story_id] = checked;
    });
    setCheckedMap(newMap);
  };

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [searchText, setSearchText] = useState("");
  const [typeFilter, setTypeFilter] = useState("All");
  const [isTypeOpen, setIsTypeOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const filteredEntries = entries.filter((entry) => {
    const meetsId = selectedIds.length === 0 || selectedIds.includes(entry.user_story_id);
    const meetsType = typeFilter === "All" || typeFilter === "Functional"; // Default to Functional as no type field
    const meetsSearch =
      searchText.trim() === "" ||
      entry.user_story.toLowerCase().includes(searchText.toLowerCase()) ||
      entry.user_story_id.toLowerCase().includes(searchText.toLowerCase()) ||
      entry.acceptance_criteria.some(ac => ac.toLowerCase().includes(searchText.toLowerCase())) ||
      entry.gherkin_feature.toLowerCase().includes(searchText.toLowerCase()) ||
      entry.gherkin_scenarios.some((scenario) =>
        scenario.name.toLowerCase().includes(searchText.toLowerCase()) ||
        scenario.steps.some((step) => step.toLowerCase().includes(searchText.toLowerCase()))
      ) ||
      entry.test_cases.some(tc =>
        tc.title.toLowerCase().includes(searchText.toLowerCase()) ||
        tc.precondition.toLowerCase().includes(searchText.toLowerCase()) ||
        tc.expected_result.toLowerCase().includes(searchText.toLowerCase()) ||
        tc.steps.some(step => step.toLowerCase().includes(searchText.toLowerCase()))
      );
    return meetsId && meetsSearch && meetsType;
  });

  const [sortConfig, setSortConfig] = useState<{ key: string; direction: "asc" | "desc" } | null>(null);
  const totalPages = Math.ceil(filteredEntries.length / 5);
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 5;

  const handleSort = (key: string) => {
    setSortConfig((prev) => {
      if (prev?.key === key) {
        return { key, direction: prev.direction === "asc" ? "desc" : "asc" };
      }
      return { key, direction: "asc" };
    });
  };

  const sortedEntries = [...filteredEntries].sort((a, b) => {
    if (!sortConfig) return 0;
    const { key, direction } = sortConfig;
    const aVal = a[key as keyof typeof a] || "";
    const bVal = b[key as keyof typeof b] || "";
    const comparison = aVal.toString().localeCompare(bVal.toString());
    return direction === "asc" ? comparison : -comparison;
  });

  const uniqueTypes = ["Functional"]; // Static as no type field

  const toggleId = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleRegenerate = async () => {
    if (!combinedPayload) return;
    setIsLoading(true);
    try {
      const response = await fetch("http://127.0.0.1:8000/newtraceability", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(combinedPayload),
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`);
      }
      const data = await response.json();
      setEntries(data.traceability || []);
      setShowSuccess(true);
      const timer = setTimeout(() => {
        setShowSuccess(false);
      }, 5000);
      return () => clearTimeout(timer);
    } catch (err) {
      console.error("Traceability generation error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const selectedVisibleCount = filteredEntries.filter(entry => checkedMap[entry.user_story_id]).length;

  return (
    <div className="p-2 gap-2 h-93 bg-[#f6f6f6] dark:bg-[#181818] text-black dark:text-white rounded-lg">
      <div className="flex flex-row justify-between border-b border-gray-700">
        <div className="flex flex-col">
          <h1 className="text-[16px] font-semibold">Traceability</h1>
          <p className="text-[12px] text-gray-400">Validate {entries.length} User Stories</p>
        </div>
        <Button
          className="bg-white text-black dark:bg-white dark:text-black text-xs rounded-md border border-gray-500"
          onClick={() => handleDownload(selectedEntriesForDownload)}
          disabled={!isDownloadEnabled}
        >
          <Download className="w-2 h-2" /> Traceability Matrix
        </Button>
      </div>

      <div className="flex gap-2 items-center mt-2">
        <Input
          placeholder="Filter tasks..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          className="w-1/4"
        />
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              className="border border-dashed border-gray-400 px-4 py-2 rounded-lg flex items-center gap-2 text-black dark:text-white"
            >
              <CirclePlus className="w-4 h-4" /> US ID
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-27 bg-gray-900 border-gray-700 text-white p-4 rounded-lg shadow-xl">
            <ScrollArea className="h-34 w-full pr-2">
              <div className="flex flex-col gap-2">
                {entries.map((entry) => (
                  <label key={entry.user_story_id} className="flex items-center gap-2 text-sm">
                    <Checkbox
                      id={`checkbox-${entry.user_story_id}`}
                      checked={selectedIds.includes(entry.user_story_id)}
                      onCheckedChange={() => toggleId(entry.user_story_id)}
                    />
                    <span className="text-white font-medium">{entry.user_story_id}</span>
                  </label>
                ))}
              </div>
              <ScrollBar orientation="vertical" />
            </ScrollArea>
          </PopoverContent>
        </Popover>

        <Popover open={isTypeOpen} onOpenChange={setIsTypeOpen}>
          <PopoverTrigger asChild>
            <Button variant="ghost" className="border border-dashed border-gray-400 px-4 py-2 rounded-lg">
              <CirclePlus className="w-4 h-4" /> Category
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48 p-0 bg-gray-900 border-gray-700 text-white">
            <Command>
              <CommandGroup>
                {["All", ...uniqueTypes].map((option) => (
                  <CommandItem
                    key={option}
                    onSelect={() => {
                      setTypeFilter(option);
                      setIsTypeOpen(false);
                    }}
                    className={typeFilter === option ? "bg-gray-700 text-white" : ""}
                  >
                    {option}
                  </CommandItem>
                ))}
              </CommandGroup>
            </Command>
          </PopoverContent>
        </Popover>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="ml-auto text-sm text-black dark:text-white border border-dashed border-gray-500 px-3 py-2">
              Clear Options <EllipsisVertical />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-40 text-black dark:text-white border border-gray-700">
            <DropdownMenuItem onClick={() => {
              setSearchText("");
              setSelectedIds([]);
              setTypeFilter("All");
            }}>
              <RotateCcw className="mr-1 w-4 h-4" /> Clear Filters
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setSortConfig(null)}>
              <FunnelX /> Clear Sort
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => {
              setSearchText("");
              setSelectedIds([]);
              setSortConfig(null);
              setTypeFilter("All");
              setCheckedMap({});
            }}>
              <BrushCleaning /> Clear All
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {(selectedIds.length > 0 || searchText !== "" || sortConfig !== null) && (
        <div className="flex flex-wrap gap-2 px-1 py-1 mb-2 text-xs text-black dark:text-white">
          {selectedIds.length > 0 && (
            <div className="bg-purple-800 text-white px-2 py-1 rounded-full">
              US IDs: {selectedIds.join(", ")}
            </div>
          )}
          {searchText !== "" && (
            <div className="bg-green-800 text-white px-2 py-1 rounded-full">
              Search: "{searchText}"
            </div>
          )}
          {sortConfig && (
            <div className="bg-blue-800 text-white px-2 py-1 rounded-full">
              Sorted by {sortConfig.key} ({sortConfig.direction})
            </div>
          )}
        </div>
      )}

      <div className="w-full h-70 flex flex-col">
        <div className="border flex flex-col overflow-hidden scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200 rounded-lg">
          <Table className="min-w-[2000px] text-sm text-left text-white">
            <TableHeader className="sticky top-0 z-10 bg-white dark:bg-[#111111] text-black dark:text-white">
              <TableRow>
                <TableHead onClick={() => handleSort("user_story_id")} className="px-4 py-2 cursor-pointer">
                  <div className="inline-flex items-center gap-1 whitespace-nowrap">
                    US ID
                    {sortConfig?.key === "user_story_id" ? (
                      sortConfig.direction === "asc" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronsUpDown className="w-4 h-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("user_story")} className="px-4 py-2 cursor-pointer">
                  <div className="inline-flex items-center gap-1 whitespace-nowrap">
                    User Story
                    {sortConfig?.key === "user_story" ? (
                      sortConfig.direction === "asc" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronsUpDown className="w-4 h-4" />
                    )}
                  </div>
                </TableHead>
                {/* <TableHead onClick={() => handleSort("usid")} className="px-4 py-2 cursor-pointer">
                  <div className="inline-flex items-center gap-1 whitespace-nowrap">
                    US ID (Alt)
                    {sortConfig?.key === "usid" ? (
                      sortConfig.direction === "asc" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronsUpDown className="w-4 h-4" />
                    )}
                  </div>
                </TableHead> */}
                <TableHead className="px-4 py-2">
                  <div className="whitespace-nowrap">
                    Confidence Level
                  </div>
                </TableHead>
                <TableHead className="px-4 py-2">
                  <div className="whitespace-nowrap">
                    Validation Issues
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("acceptance_criteria")} className="px-4 py-2 cursor-pointer">
                  <div className="inline-flex items-center gap-1 whitespace-nowrap">
                    Acceptance Criteria
                    {sortConfig?.key === "acceptance_criteria" ? (
                      sortConfig.direction === "asc" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronsUpDown className="w-4 h-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("gherkin_feature")} className="px-4 py-2 cursor-pointer">
                  <div className="inline-flex items-center gap-1 whitespace-nowrap">
                    Gherkin Feature
                    {sortConfig?.key === "gherkin_feature" ? (
                      sortConfig.direction === "asc" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronsUpDown className="w-4 h-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("gherkin_scenarios")} className="px-4 py-2 cursor-pointer">
                  <div className="inline-flex items-center gap-1 whitespace-nowrap">
                    Gherkin Scenarios
                    {sortConfig?.key === "gherkin_scenarios" ? (
                      sortConfig.direction === "asc" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronsUpDown className="w-4 h-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("test_cases")} className="px-4 py-2 cursor-pointer">
                  <div className="inline-flex items-center gap-1 whitespace-nowrap">
                    Test Cases
                    {sortConfig?.key === "test_cases" ? (
                      sortConfig.direction === "asc" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronsUpDown className="w-4 h-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      className="bg-white border border-gray-500 dark:border-gray-900 dark:bg-[#414143] dark:text-black"
                      checked={
                        entries.length > 0 &&
                        Object.values(checkedMap).length === entries.length &&
                        Object.values(checkedMap).every(Boolean)
                      }
                      onCheckedChange={(checked) => toggleSelectAllDownloadCheckboxes(!!checked)}
                    />
                    Extract Requirements
                  </div>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedEntries
                .slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage)
                .map((entry, index) => (
                  <TableRow
                    key={entry.user_story_id}
                    className={`text-black dark:text-white text-sm rounded-lg overflow-hidden ${
                      index % 2 === 0 ? 'bg-[#d0d0d0] dark:bg-[#181818]' : 'bg-[#ececec] dark:bg-[#2a2a2a]'
                    }`}
                  >
                    <TableCell className="px-4 py-2 align-top">{entry.user_story_id}</TableCell>
                    <TableCell className="px-4 py-2 align-top whitespace-normal break-words max-w-xs">{entry.user_story}</TableCell>
                    {/* <TableCell className="px-4 py-2 align-top">{entry.usid || 'N/A'}</TableCell> */}
                    <TableCell className="px-4 py-2 align-top">
                      <ConfidenceBadge confidence={1.0} /> {/* Default confidence */}
                    </TableCell>
                    <TableCell className="px-4 py-2 align-top whitespace-normal break-words max-w-xs">
                      No validation issues 
                    </TableCell>
                    <TableCell className="px-4 py-2 align-top whitespace-normal break-words max-w-xs">
                      <ul className="list-disc pl-4 text-sm">
                        {entry.acceptance_criteria.map((ac, idx) => (
                          <li key={idx}>{ac}</li>
                        ))}
                      </ul>
                    </TableCell>
                    <TableCell className="px-4 py-2 align-top whitespace-normal break-words max-w-xs">{entry.gherkin_feature}</TableCell>
                    <TableCell className="px-4 py-2 align-top whitespace-normal break-words max-w-xs">
                      {entry.gherkin_scenarios.map((scenario, sIndex) => (
                        <div key={sIndex} className="mb-2">
                          <div className="font-medium">{scenario.name}</div>
                          <ul className="list-disc pl-4 text-sm text-[#bababa]">
                            {scenario.steps.map((step, stepIndex) => (
                              <li key={stepIndex}>{step}</li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </TableCell>
                    <TableCell className="px-4 py-2 align-top whitespace-normal break-words max-w-xs">
                      {entry.test_cases.map((tc, tcIndex) => (
                        <div key={tcIndex} className="mb-2">
                          <div className="font-medium">{tc.test_id}: {tc.title}</div>
                          <p className="text-sm text-gray-600">Precondition: {tc.precondition}</p>
                          <ul className="list-disc pl-4 text-sm">
                            {tc.steps.map((step, sIndex) => (
                              <li key={sIndex}>{step}</li>
                            ))}
                          </ul>
                          <p className="text-sm font-medium">Expected: {tc.expected_result}</p>
                          <Badge variant="secondary">{tc.priority}</Badge>
                        </div>
                      ))}
                    </TableCell>
                    <TableCell className="align-top px-4 py-2">
                      <div className="flex">
                        <Checkbox
                          className="border border-gray-500 dark:border-gray-900 dark:bg-[#414143] dark:text-black"
                          checked={!!checkedMap[entry.user_story_id]}
                          onCheckedChange={() => toggleDownloadCheckbox(entry.user_story_id)}
                        />
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>
      </div>

      <div className="flex justify-between items-center h-9 border-b border-gray-700 text-sm bg-[#f6f6f6] dark:bg-black text-black dark:text-white">
        <div className="text-black dark:text-gray-400 m-1.5">
          {`${selectedVisibleCount} of ${filteredEntries.length} row(s) selected.`}
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-black dark:text-white">Rows per page</span>
            <select
              className="bg-black border border-gray-700 text-white rounded px-2 py-1"
              value={rowsPerPage}
              onChange={(e) => {
                setCurrentPage(1);
              }}
            >
              {[5, 10, 25].map((val) => (
                <option key={val} value={val}>{val}</option>
              ))}
            </select>
          </div>
          <div className="text-black dark:text-white">
            Page {currentPage} of {totalPages}
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => setCurrentPage(1)} disabled={currentPage === 1} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&laquo;</button>
            <button onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&lsaquo;</button>
            <button onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&rsaquo;</button>
            <button onClick={() => setCurrentPage(totalPages)} disabled={currentPage === totalPages} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&raquo;</button>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center gap-2 mt-2">
        <div className="min-h-[24px] flex items-center">
          {showSuccess && (
            <span className="flex flex-row gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 30.266 30.266" className="mt-1">
                <path d="M30.266,15.133A15.133,15.133,0,1,1,15.133,0,15.133,15.133,0,0,1,30.266,15.133ZM22.756,9.4a1.419,1.419,0,0,0-2.043.042l-6.57,8.37-3.959-3.961a1.419,1.419,0,0,0-2.005,2.005l5.005,5.007a1.419,1.419,0,0,0,2.041-.038l7.551-9.439A1.419,1.419,0,0,0,22.758,9.4Z" fill="#24d304" />
              </svg>
              Traceability generated Successfully!
            </span>
          )}
        </div>
        <div className="flex gap-2">
          <Button
            className="bg-white dark:bg-[#0D0D0D] text-black dark:text-white border border-gray-400"
            disabled={filteredEntries.length === 0 || isLoading}
            onClick={handleRegenerate}
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4 text-black dark:text-white" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                </svg>
                Regenerating...
              </span>
            ) : (
              "Regenerate Response"
            )}
          </Button>
          {/* {goToLogs && (
            <Button
              className="bg-black text-white dark:bg-[#E5E5E5] dark:text-black"
              disabled={filteredEntries.length === 0}
              onClick={goToLogs}
            >
              Generate Logs
            </Button>
          )} */}
        </div>
      </div>
    </div>
  );
}