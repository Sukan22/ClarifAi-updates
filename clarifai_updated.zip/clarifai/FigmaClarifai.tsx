'use client';
import * as React from 'react';
import { useState, useEffect } from 'react';
import ImageUploadTab from './ImageUploadTab';
import FigmaUserStoriesTab from './FigmaUserStoriesTab';
import GherkinTab from './GherkinTab';
import TestCasesTab from './TestCasesTab';
import FigmaTraceabilityTab from './FigmaTraceabilityTab';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

const steps = [
  { value: 'upload', label: '1. Upload Image' },
  { value: 'user stories', label: '2. User Stories' },
  { value: 'gherkin', label: '3. Gherkin' },
  { value: 'test cases', label: '4. Test Cases' },
  { value: 'traceability', label: '5. Traceability' },
];

export default function FigmaClarifai({ onBack }: { onBack?: () => void }) {
  const [activeTab, setActiveTab] = useState('upload');
  const [completedSteps, setCompletedSteps] = useState<{ [key: string]: boolean }>({
    upload: false,
    'user stories': false,
    gherkin: false,
    'test cases': false,
    traceability: false,
  });
  const [enabledSteps, setEnabledSteps] = useState([0]);
  const [userstoriesPayload, setUserstoriesPayload] = useState<any>(null);
  const [userstoriesRequirements, setUserstoriesRequirements] = useState<any[]>([]);
  const [gerkinPayload, setGerkinPayload] = useState<any>(null);
  const [gerkinRequirements, setGerkinRequirements] = useState<any[]>([]);
  const [testcasePayload, setTestcasePayload] = useState<any>(null);
  const [testcaseRequirement, setTestcaseRequirement] = useState<any[]>([]);
  const [traceabilityRequirements, setTraceabilityRequirements] = useState<any[]>([]);
  const [isTraceabilityLoading, setIsTraceabilityLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const combinedPayload = {
    user_stories: userstoriesRequirements.map(story => ({ additionalProp1: story })),
    gherkin_scenarios: gerkinRequirements.map(scenario => ({ additionalProp1: scenario })),
    test_cases: testcaseRequirement.map(testcase => ({ additionalProp1: testcase })),
  };

  useEffect(() => {
    sessionStorage.clear();
  }, []);

  useEffect(() => {
    const savedId = sessionStorage.getItem("editingId");
    if (savedId) setEditingId(savedId);
  }, []);

  useEffect(() => {
    if (editingId !== null) {
      sessionStorage.setItem("editingId", editingId);
    } else {
      sessionStorage.removeItem("editingId");
    }
  }, [editingId]);

  const isStepEnabled = (index: number) => index === 0 || enabledSteps.includes(index);

  const handleGenerateUserStories = async (data: { user_stories: any[] }) => {
    try {
      const mappedStories = data.user_stories.map((story: any) => ({
        ...story,
        requirement_id: story.user_story_id,
      }));

      setUserstoriesPayload(data);
      setUserstoriesRequirements(mappedStories);
      setCompletedSteps((prev) => ({ ...prev, upload: true, 'user stories': true }));
      setEnabledSteps((prev) => [...new Set([...prev, 1])]);
      setActiveTab('user stories');
    } catch (error) {
      console.error("Failed to process user stories:", error);
      setCompletedSteps((prev) => ({ ...prev, upload: false, 'user stories': false }));
    }
  };

  const goToGherkin = (fullPayload: any) => {
    setGerkinPayload(fullPayload);
    setGerkinRequirements(fullPayload.gherkin_scenarios);
    setEnabledSteps((prev) => [...new Set([...prev, 2])]);
    setActiveTab('gherkin');
    setCompletedSteps((prev) => ({ ...prev, gherkin: true }));
  };

  const goToTestCases = (fullPayload: any) => {
    setTestcasePayload(fullPayload);
    setTestcaseRequirement(fullPayload.test_cases);
    setEnabledSteps((prev) => [...new Set([...prev, 3])]);
    setActiveTab('test cases');
    setCompletedSteps((prev) => ({ ...prev, 'test cases': true }));
  };

  const goToTraceability = async () => {
    try {
      setIsTraceabilityLoading(true);
      const response = await fetch("http://127.0.0.1:8000/newtracability", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(combinedPayload),
      });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const result = await response.json();
      setTraceabilityRequirements(result.traceability);
      setEnabledSteps((prev) => [...new Set([...prev, 4])]);
      setActiveTab('traceability');
      setCompletedSteps((prev) => ({ ...prev, traceability: true }));
    } catch (error) {
      console.error("Failed to submit traceability data:", error);
    } finally {
      setIsTraceabilityLoading(false);
    }
  };

  return (
    <>
      {onBack && (
        <button onClick={onBack} className="mb-4 text-sm text-primary hover:underline">
          ← Back to Approaches
        </button>
      )}
      <div className="w-full">
        <Tabs value={activeTab} onValueChange={(val) => {
          const currentIndex = steps.findIndex((s) => s.value === val);
          if (isStepEnabled(currentIndex)) setActiveTab(val);
        }}>
          <TabsList className="grid grid-cols-5 w-full bg-[#ececec] dark:bg-[#2e2D2D] rounded-md h-[6.5vh]">
            {steps.map((step, index) => {
              const isCompleted = completedSteps[step.value];
              const isDisabled = !isStepEnabled(index);
              return (
                <TabsTrigger
                  key={step.value}
                  value={step.value}
                  disabled={isDisabled}
                  className={cn(
                    "w-full rounded-md px-2 py-2 text-xs font-medium transition-all flex items-center justify-center gap-2",
                    activeTab === step.value ? 'bg-purple-500 text-white' : 'text-black dark:text-white',
                    isDisabled && 'opacity-50 pointer-events-none cursor-not-allowed'
                  )}
                >
                  <div className={`w-4 h-4 rounded-md border flex items-center justify-center text-[9px] ${
                    isCompleted ? 'bg-green-500 border-green-500' : activeTab === step.value ? 'bg-[#B164FF]' : 'bg-black'
                  }`}>
                    {isCompleted && <Check className="w-2 h-2 text-black" />}
                  </div>
                  {step.label}
                </TabsTrigger>
              );
            })}
          </TabsList>

          <TabsContent value="upload">
            <ImageUploadTab
              isUploadComplete={completedSteps.upload}
              onGenerateUserStories={handleGenerateUserStories}
            />
          </TabsContent>
          <TabsContent value="user stories">
            <FigmaUserStoriesTab
              goTogerkin={goToGherkin}
              userstoriesData={userstoriesRequirements}
              fulluserstoriesdataPayload={userstoriesPayload}
              fullValidatorPayload={null}
              onUpdatedUserStoriesData={setUserstoriesRequirements}
              onUpdateUserStoriesPayload={setUserstoriesPayload}
            />
          </TabsContent>
          <TabsContent value="gherkin">
            <GherkinTab goTotestcases={goToTestCases} gherkinData={gerkinRequirements} fullGherkinDataPayload={gerkinPayload} // Fixed typo: fullgerkinDataPayload → fullGherkinDataPayload
    fullUserStoriesPayload={userstoriesPayload}/>
          </TabsContent>
          <TabsContent value="test cases">
            <TestCasesTab
              goToTraceability={goToTraceability}
              testcaseData={testcaseRequirement}
              fulltestcaseDataPayload={testcasePayload}
              isLoading={isTraceabilityLoading}
              fulluserstoriesPayload={userstoriesPayload}
            />
          </TabsContent>
          <TabsContent value="traceability">
            <FigmaTraceabilityTab
              traceabilityData={traceabilityRequirements}
              combinedPayload={combinedPayload}
            />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}

//  <TabsContent value="gherkin">
//   <GherkinTab
//     goTotestcases={goTotestcases}
//     gherkinData={gerkinRequirements} // For displaying Gherkin scenarios
//     fullGherkinDataPayload={gerkinPayload} // Fixed typo: fullgerkinDataPayload → fullGherkinDataPayload
//     fullUserStoriesPayload={userstoriesPayload} // Add this prop for test case generation
//   />
// </TabsContent>