import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

type Story = {
  usid: string;
  title: string;
  role: string;
  story: string;
  description: string;
  acceptanceCriteria: string[];
  tshirt_size: string;
  priority: string;
  tags: string[];
  confidence: number;
  priorityScore?: number;
};

interface FeedbackModalProps {
  story: Story | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedStory: Story, feedback: string) => void;
}

export default function FeedbackModal({ story, isOpen, onClose, onSave }: FeedbackModalProps) {
  const [feedback, setFeedback] = useState("");
  const [loading, setLoading] = useState(false);
  const [sendClicked, setSendClicked] = useState(false);
  const [updatedStory, setUpdatedStory] = useState<Story | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editableStory, setEditableStory] = useState<Story | null>(null);
  const [showDialogMessage, setShowDialogMessage] = useState<string>("");
  const recognitionRef = useRef<any>(null);
  const timeroutRef = useRef<any>(null);
  const [listening, setListening] = useState(false);

  const handleRefineSubmit = async () => {
    if (!feedback.trim() || !story) return;
    setLoading(true);
    setSendClicked(true);

    try {
      const res = await fetch("http://127.0.0.1:8000/update-story", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ story, feedback }),
      });

      const updated = await res.json();
      const normalizedConfidence = story?.confidence ?? 0.5;
      const normalizedStory: Story = {
        ...updated.updated_story,
        usid: updated.updated_story.usid || story.usid,
        acceptanceCriteria: updated.updated_story.acceptanceCriteria || updated.updated_story.acceptance_criteria || story.acceptanceCriteria,
        description: updated.updated_story.description || updated.updated_story["Description/Note"] || story.description,
        tags: updated.updated_story.tags || updated.updated_story["Tags/Labels"] || story.tags,
        confidence: normalizedConfidence,
        priorityScore: getPriorityScore(updated.updated_story.priority || story.priority),
      };
      setUpdatedStory(normalizedStory);
      setEditableStory(normalizedStory);
      setFeedback("");
      setShowDialogMessage("Feedback edited successfully");
      setTimeout(() => setShowDialogMessage(""), 3000);
    } catch (err) {
      console.error("LLM update failed:", err);
    } finally {
      setLoading(false);
      setTimeout(() => setSendClicked(false), 300);
    }
  };

  const getPriorityScore = (priority: string): number => {
    switch (priority?.toLowerCase()) {
      case "high":
        return 0.9;
      case "medium":
        return 0.5;
      case "low":
        return 0.1;
      default:
        return 0.5;
    }
  };

  const handleSave = () => {
    if (!updatedStory || !story) return;
    const finalStory = isEditing ? editableStory : updatedStory;
    const normalizedConfidence = finalStory?.confidence ?? story.confidence ?? 0.5;
    const normalizedPriorityScore = getPriorityScore(finalStory?.priority || story.priority);
    const normalizedStory: Story = {
      ...finalStory,
      confidence: normalizedConfidence,
      priorityScore: normalizedPriorityScore,
      description: finalStory?.description || finalStory?.["Description/Note"] || story.description,
      tags: finalStory?.tags || finalStory?.["Tags/Labels"] || story.tags,
      acceptanceCriteria: finalStory?.acceptanceCriteria || finalStory?.acceptance_criteria || story.acceptanceCriteria,
    };
    onSave(normalizedStory, feedback);
    onClose();
  };

  const handleVoiceInput = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Speech recognition not supported in this browser.");
      return;
    }

    if (recognitionRef.current && listening) {
      recognitionRef.current.stop();
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.continuous = true;

    recognition.onstart = () => setListening(true);
    recognition.onend = () => {
      setListening(false);
      recognitionRef.current = null;
      if (timeroutRef.current) {
        clearTimeout(timeroutRef.current);
      }
    };

    recognition.onresult = (event: any) => {
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        transcript += event.results[i][0].transcript;
      }

      setFeedback((prev) => (prev ? prev + " " + transcript : transcript));
      if (timeroutRef.current) {
        clearTimeout(timeroutRef.current);
      }
      timeroutRef.current = setTimeout(() => {
        recognition.stop();
      }, 2000);
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error:", event.error);
      setListening(false);
    };

    recognition.start();
    recognitionRef.current = recognition;
  };

  if (!story) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[800px] bg-[#1a1a1a] text-white p-4 rounded-xl shadow-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-sm text-gray-400">Refine User Story</DialogTitle>
        </DialogHeader>
        {showDialogMessage && (
          <div className="mb-4 flex items-center gap-2 p-3 bg-green-100 dark:bg-green-900 rounded-md text-green-800 dark:text-green-200">
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 30.266 30.266">
              <path d="M30.266,15.133A15.133,15.133,0,1,1,15.133,0,15.133,15.133,0,0,1,30.266,15.133ZM22.756,9.4a1.419,1.419,0,0,0-2.043.042l-6.57,8.37-3.959-3.961a1.419,1.419,0,0,0-2.005,2.005l5.005,5.007a1.419,1.419,0,0,0,2.041-.038l7.551-9.439A1.419,1.419,0,0,0,22.758,9.4Z" fill="#24d304" />
            </svg>
            {showDialogMessage}
          </div>
        )}
        <div className="relative mt-2 mb-4">
          <input
            type="text"
            placeholder="Type your feedback..."
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            className="w-full pr-20 pl-4 py-2 rounded-md border border-gray-700 bg-gray-900 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
            aria-label="Feedback input"
          />
          <button
            onClick={handleVoiceInput}
            className={`absolute right-10 top-1/2 -translate-y-1/2 p-2 rounded-full ${
              listening ? "bg-red-600" : "bg-gray-700"
            } text-white transition duration-200 ease-in-out hover:scale-105 hover:shadow-md`}
            aria-label="Voice input"
            title="Voice input"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
          </button>
          <button
            onClick={handleRefineSubmit}
            disabled={loading || !feedback.trim()}
            className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-purple-600 text-white transition duration-200 ease-in-out
              ${!loading && "hover:scale-105 hover:shadow-md"} 
              ${sendClicked ? "animate-ping" : ""}`}
            aria-label="Send feedback"
            title="Send"
          >
         <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12l14-7-4 4h4v6h-4l4 4z" />
</svg>
          </button>
        </div>
        {updatedStory && (
          <div className="p-4 border border-gray-700 rounded-md bg-gray-900 text-sm space-y-3 max-h-full overflow-y-auto flex-1">
            {isEditing ? (
              <>
                <div>
                  <span className="text-gray-400">User Story ID:</span>
                  <input
                    value={editableStory?.usid}
                    onChange={(e) =>
                      setEditableStory({ ...editableStory!, usid: e.target.value })
                    }
                    className="w-full mt-1 bg-gray-800 text-white p-2 rounded-md border border-gray-700"
                  />
                </div>
                <div>
                  <span className="text-gray-400">Title:</span>
                  <input
                    value={editableStory?.title}
                    onChange={(e) =>
                      setEditableStory({ ...editableStory!, title: e.target.value })
                    }
                    className="w-full mt-1 bg-gray-800 text-white p-2 rounded-md border border-gray-700"
                  />
                </div>
                <div>
                  <span className="text-gray-400">Role:</span>
                  <input
                    value={editableStory?.role}
                    onChange={(e) =>
                      setEditableStory({ ...editableStory!, role: e.target.value })
                    }
                    className="w-full mt-1 bg-gray-800 text-white p-2 rounded-md border border-gray-700"
                  />
                </div>
                <div>
                  <span className="text-gray-400">Story:</span>
                  <textarea
                    value={editableStory?.story}
                    onChange={(e) =>
                      setEditableStory({ ...editableStory!, story: e.target.value })
                    }
                    className="w-full mt-1 bg-gray-800 text-white p-2 rounded-md border border-gray-700"
                    rows={3}
                  />
                </div>
                <div>
                  <span className="text-gray-400">Description:</span>
                  <textarea
                    value={editableStory?.description}
                    onChange={(e) =>
                      setEditableStory({ ...editableStory!, description: e.target.value })
                    }
                    className="w-full mt-1 bg-gray-800 text-white p-2 rounded-md border border-gray-700"
                    rows={3}
                  />
                </div>
                <div>
                  <span className="text-gray-400">T-shirt Size:</span>
                  <input
                    value={editableStory?.tshirt_size}
                    onChange={(e) =>
                      setEditableStory({ ...editableStory!, tshirt_size: e.target.value })
                    }
                    className="w-full mt-1 bg-gray-800 text-white p-2 rounded-md border border-gray-700"
                  />
                </div>
                <div>
                  <span className="text-gray-400">Priority:</span>
                  <input
                    value={editableStory?.priority}
                    onChange={(e) =>
                      setEditableStory({ ...editableStory!, priority: e.target.value })
                    }
                    className="w-full mt-1 bg-gray-800 text-white p-2 rounded-md border border-gray-700"
                  />
                </div>
                <div>
                  <span className="text-gray-400">Acceptance Criteria:</span>
                  <textarea
                    value={editableStory?.acceptanceCriteria.join("\n")}
                    onChange={(e) =>
                      setEditableStory({
                        ...editableStory!,
                        acceptanceCriteria: e.target.value.split("\n"),
                      })
                    }
                    className="w-full mt-1 bg-gray-800 text-white p-2 rounded-md border border-gray-700"
                    rows={8}
                  />
                </div>
                <div>
                  <span className="text-gray-400">Labels/Tags:</span>
                  <textarea
                    value={editableStory?.tags.join("\n")}
                    onChange={(e) =>
                      setEditableStory({
                        ...editableStory!,
                        tags: e.target.value.split("\n"),
                      })
                    }
                    className="w-full mt-1 bg-gray-800 text-white p-2 rounded-md border border-gray-700"
                    rows={8}
                  />
                </div>
                <div className="flex justify-end gap-2 mt-4">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md"
                  >
                    Clear
                  </button>
                  <button
                    onClick={() => {
                      setUpdatedStory(editableStory);
                      setIsEditing(false);
                    }}
                    className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md"
                  >
                    Save Edits
                  </button>
                </div>
              </>
            ) : (
              <>
                <div>
                  <span className="text-gray-400">User Story ID:</span>{" "}
                  <span className="text-white">{updatedStory.usid}</span>
                </div>
                <div>
                  <span className="text-gray-400">Title:</span>{" "}
                  <span className="text-white">{updatedStory.title}</span>
                </div>
                <div>
                  <span className="text-gray-400">Role:</span>{" "}
                  <span className="text-white">{updatedStory.role}</span>
                </div>
                <div>
                  <span className="text-gray-400">Story:</span>{" "}
                  <span className="text-white">{updatedStory.story}</span>
                </div>
                <div>
                  <span className="text-gray-400">Description:</span>{" "}
                  <span className="text-white">{updatedStory.description}</span>
                </div>
                <div>
                  <span className="text-gray-400">T-shirt Size:</span>{" "}
                  <span className="text-white">{updatedStory.tshirt_size}</span>
                </div>
                <div>
                  <span className="text-gray-400">Priority:</span>{" "}
                  <span className="text-white">{updatedStory.priority}</span>
                </div>
                <div>
                  <span className="text-gray-400">Acceptance Criteria:</span>
                  <ul className="list-disc pl-5 text-white mt-1 space-y-1">
                    {updatedStory.acceptanceCriteria.map((item: string, idx: number) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <span className="text-gray-400">Labels/Tags:</span>
                  <ul className="list-disc pl-5 text-white mt-1 space-y-1">
                    {updatedStory.tags.map((item: string, idx: number) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
                <div className="flex justify-end gap-2 mt-4">
                  <button
                    onClick={() => setUpdatedStory(null)}
                    className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md"
                  >
                    Cancel Edit
                  </button>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="bg-yellow-500 hover:bg-yellow-600 text-black px-4 py-2 rounded-md"
                  >
                    Edit
                  </button>
                  <button
                    onClick={handleSave}
                    className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md"
                  >
                    Save
                  </button>
                </div>
              </>
            )}
          </div>
        )}
        <DialogFooter className="bg-[#1a1a1a] border-t border-gray-700 p-4">
          <Button variant="ghost" onClick={onClose} className="mr-auto">Cancel</Button>
          <Button onClick={handleSave} disabled={!updatedStory}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 