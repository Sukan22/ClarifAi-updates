'use client';
import * as React from 'react';
import { useState } from 'react';
import BRDClarifai from './BRDClarifai';  
import FigmaClarifai from './FigmaClarifai';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Side_clarifyAi } from "@/components/icons/SidebarIcons";
import { cn } from '@/lib/utils';

export default function Clarifai() {
  const [selectedFlow, setSelectedFlow] = useState<'brd' | 'figma' | null>(null);

  if (selectedFlow === 'brd') {
    return <BRDClarifai onBack={() => setSelectedFlow(null)} />;
  }

  if (selectedFlow === 'figma') {
    return <FigmaClarifai onBack={() => setSelectedFlow(null)} />;
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] p-8 bg-background">
      <h1 className="text-3xl font-bold mb-8">CLARIFAI High Level Generator</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
        {/* BRD Card */}
        <Card 
          className={cn("cursor-pointer h-[28vh] w-[28vw] hover:shadow-lg transition-shadow", selectedFlow && "opacity-50")}
          onClick={() => setSelectedFlow('brd')}
        >
          <CardHeader className="h-[9vh]">
            {/* Title with border and background */}
            <div className="bg-[#171515] border border-gray-300 dark:border-gray-700 p-4 mb-4 rounded-md">
              <CardTitle className="text-white text-center">
                <div className="flex items-center justify-center gap-2">
                  <Side_clarifyAi className="w-6 h-6" />
                  <span>BRD</span>
                </div>
              </CardTitle>
            </div>
            <CardDescription className="text-gray-600 dark:text-gray-200 text-center">
              Full workflow: Upload docs → Classify → Validate → Stories → Gherkin → Tests → Traceability
            </CardDescription>
            <p style={{ textAlign: 'center', fontSize: '12px' }}>Proceed →</p>
          </CardHeader>
        </Card>

        {/* Figma Card */}
        <Card 
          className={cn("cursor-pointer h-[28vh] w-[28vw] hover:shadow-lg transition-shadow", selectedFlow && "opacity-50")}
          onClick={() => setSelectedFlow('figma')}
        >
          <CardHeader className="h-[9vh]">
            {/* Title with border and background */}
            <div className="bg-[#171515] border border-gray-300 dark:border-gray-700 p-4 mb-4 rounded-md">
              <CardTitle className="text-white text-center">
                <div className="flex items-center justify-center gap-2">
                  <Side_clarifyAi className="w-6 h-6" />
                  <span>Figma Designs</span>
                </div>
              </CardTitle>
            </div>
            <CardDescription className="text-gray-600 dark:text-gray-200 text-center">
              Simplified: Upload images → Auto-generate Stories → Gherkin → Tests → Traceability
            </CardDescription>
            <p style={{ textAlign: 'center', fontSize: '12px' }}>Proceed →</p>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
}